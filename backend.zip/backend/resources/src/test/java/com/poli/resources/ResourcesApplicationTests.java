package com.poli.resources;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ResourcesApplicationTests {

	@Test
	void contextLoads() {
	}

}
