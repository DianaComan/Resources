package main.Services;

public interface SubscriptionsService {
    String createSubscription(String username, String resourceName);
}
