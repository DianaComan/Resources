
drop table resources.organizations;
drop table resources.users;
drop table resources.resources;
drop table resources.subscriptions;

CREATE TABLE resources.organizations(ID INT,NAME VARCHAR(100), PRIMARY KEY (ID));
CREATE TABLE resources.users(ID INT,USERNAME VARCHAR(100),PASSWORD VARCHAR(100),ROLE VARCHAR(100),FIRSTNAME VARCHAR(100),LASTNAME VARCHAR(100),EMAIL VARCHAR(100),ORGANIZATION_ID INT, PRIMARY KEY (ID));
CREATE TABLE resources.resources(ID INT,NAME VARCHAR(100),STATUS VARCHAR(100),ORGANIZATION_ID INT, LAST_RESERVED_BY VARCHAR(100), CURRENTLY_RESERVED_BY VARCHAR(100), ESTIMATED_TIME VARCHAR(100), CURRENTLY_RESERVATION_TIME VARCHAR(100), PRIMARY KEY (ID));
CREATE TABLE resources.subscriptions(ID INT,USER_ID INT,RESOURCE_ID INT, PRIMARY KEY (ID));
ALTER TABLE resources.users MODIFY COLUMN ID INT auto_increment;
ALTER TABLE resources.subscriptions MODIFY COLUMN ID INT auto_increment;
ALTER TABLE resources.users MODIFY COLUMN ID INT auto_increment;
ALTER TABLE resources.organizations MODIFY COLUMN ID INT auto_increment;

insert into resources.organizations(id, NAME) values (-1, 'PolitehnicaBucuresti');
insert into resources.organizations(id, NAME) values (-2, 'SpitalFloreasca');
insert into resources.organizations(id, NAME) values (-3, 'SpitalUniversitar');
insert into resources.organizations(id, NAME) values (-4, 'BirouLotru');

insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-1, 'Sala_EC101', 'FREE', -1, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME,CURRENTLY_RESERVATION_TIME) values (-2, 'Sala_PR001', 'FREE', -1, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-3, 'Sala_PR002', 'FREE', -1, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-4, 'Sala_PR706', 'FREE', -1, 'none','none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-5, 'Sala_EC102', 'FREE', -1, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-6, 'Sala_EC105', 'FREE', -1, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-7, 'Sala_EC004', 'FREE', -1, 'none', 'none', 'none', 'none');

insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-8, 'Sala_operatii1', 'FREE', -2, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-9, 'Sala_operatii2', 'FREE', -2, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-10, 'Sala_operatii3', 'FREE', -2, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-11, 'Sala_operatii4', 'FREE', -2, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-12, 'Sala_operatii5', 'FREE', -2, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-13, 'Sala_conferinte1', 'FREE', -2, 'none', 'none', 'none', 'none');
insert into resources.resources(id, NAME, STATUS, ORGANIZATION_ID, LAST_RESERVED_BY, CURRENTLY_RESERVED_BY, ESTIMATED_TIME, CURRENTLY_RESERVATION_TIME) values (-14, 'Sala_conferinte2', 'FREE', -2, 'none', 'none', 'none', 'none');

insert into resources.users(id, USERNAME, PASSWORD, ROLE, FIRSTNAME, LASTNAME, EMAIL, ORGANIZATION_ID) values (-1, 'diana01', '123456', 'admin', 'Diana', 'Coman', 'dianna.c97@gmail.com', -1)

